package com.jarvis.ai;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public final class ConversationStore extends SQLiteOpenHelper {
    private static final String DB="jarvis_memory.db"; private static final int V=1;
    public ConversationStore(Context c){super(c,DB,null,V);}
    public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, ts INTEGER NOT NULL)"); db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT UNIQUE NOT NULL, ts INTEGER NOT NULL)");}
    public void onUpgrade(SQLiteDatabase db,int o,int n){}
    public synchronized void addMessage(String role,String content){ContentValues v=new ContentValues();v.put("role",role);v.put("content",content);v.put("ts",System.currentTimeMillis());getWritableDatabase().insert("messages",null,v);}
    public synchronized List<AIClient.Message> recent(int limit){List<AIClient.Message> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT role,content FROM messages ORDER BY id DESC LIMIT "+Math.max(1,limit),null); try{while(c.moveToNext())out.add(new AIClient.Message(c.getString(0),c.getString(1)));}finally{c.close();} Collections.reverse(out);return out;}
    public synchronized void remember(String content){ContentValues v=new ContentValues();v.put("content",content.trim());v.put("ts",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("memories",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
    public synchronized String memories(){StringBuilder s=new StringBuilder();Cursor c=getReadableDatabase().rawQuery("SELECT content FROM memories ORDER BY id DESC LIMIT 50",null);try{while(c.moveToNext())s.append("• ").append(c.getString(0)).append('\n');}finally{c.close();}return s.toString().trim();}
    public synchronized void clearConversation(){getWritableDatabase().delete("messages",null,null);}
}
