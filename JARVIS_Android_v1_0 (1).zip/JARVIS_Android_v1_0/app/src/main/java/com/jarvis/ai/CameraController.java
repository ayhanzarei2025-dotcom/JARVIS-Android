package com.jarvis.ai;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.*;
import android.os.*;
import android.util.Size;
import android.view.Surface;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

/** Camera2-only controller: no CameraX/external dependency required. */
public final class CameraController {
 public interface Callback { void onFrame(File jpeg); void onError(String message); }
 private final Context context; private CameraDevice camera; private CameraCaptureSession session; private ImageReader reader;
 public CameraController(Context c){context=c.getApplicationContext();}
 @SuppressLint("MissingPermission") public void open(Surface preview, Callback cb){try{
  CameraManager cm=(CameraManager)context.getSystemService(Context.CAMERA_SERVICE);String id=chooseCamera(cm);
  if(id==null){cb.onError("No camera found");return;}CameraCharacteristics cc=cm.getCameraCharacteristics(id);StreamConfigurationMap map=cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
  Size size=chooseSize(map==null?null:map.getOutputSizes(ImageFormat.JPEG)); reader=ImageReader.newInstance(size.getWidth(),size.getHeight(),ImageFormat.JPEG,2);
  reader.setOnImageAvailableListener(r->{Image im=null;try{im=r.acquireLatestImage();if(im==null)return;ByteBufferToFile(im,cb);}catch(Exception e){cb.onError(e.getMessage());}finally{if(im!=null)im.close();}},new Handler(Looper.getMainLooper()));
  cm.openCamera(id,new CameraDevice.StateCallback(){public void onOpened(CameraDevice c){camera=c;try{List<Surface>s=Arrays.asList(preview,reader.getSurface());c.createCaptureSession(s,new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession cs){session=cs;try{CaptureRequest q=c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);q.addTarget(preview);q.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);cs.setRepeatingRequest(q.build(),null,null);}catch(Exception e){cb.onError(e.getMessage());}}public void onConfigureFailed(CameraCaptureSession x){cb.onError("Camera session failed");}},new Handler(Looper.getMainLooper()));}catch(Exception e){cb.onError(e.getMessage());}}
   public void onDisconnected(CameraDevice c){close();}public void onError(CameraDevice c,int e){cb.onError("Camera error "+e);close();}},new Handler(Looper.getMainLooper()));
 }catch(Exception e){cb.onError(e.getMessage());}}
 private String chooseCamera(CameraManager cm)throws Exception{for(String id:cm.getCameraIdList()){CameraCharacteristics c=cm.getCameraCharacteristics(id);Integer f=c.get(CameraCharacteristics.LENS_FACING);if(f!=null&&f==CameraCharacteristics.LENS_FACING_BACK)return id;}String[] ids=cm.getCameraIdList();return ids.length==0?null:ids[0];}
 private Size chooseSize(Size[] a){if(a==null||a.length==0)return new Size(1280,720);Size best=a[0];for(Size s:a)if(s.getWidth()<=1920&&s.getHeight()<=1080&&s.getWidth()*s.getHeight()>best.getWidth()*best.getHeight())best=s;return best;}
 private void ByteBufferToFile(Image im,Callback cb)throws Exception{ByteBuffer b=im.getPlanes()[0].getBuffer();byte[] d=new byte[b.remaining()];b.get(d);File f=new File(context.getCacheDir(),"jarvis_vision.jpg");try(FileOutputStream o=new FileOutputStream(f)){o.write(d);}cb.onFrame(f);}
 public void capture(Callback cb){try{if(camera==null||session==null||reader==null){cb.onError("Camera is not ready");return;}CaptureRequest q=camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);q.addTarget(reader.getSurface());q.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);session.capture(q.build(),null,new Handler(Looper.getMainLooper()));}catch(Exception e){cb.onError(e.getMessage());}}
 public void close(){try{if(session!=null)session.close();}catch(Exception ignored){}try{if(camera!=null)camera.close();}catch(Exception ignored){}try{if(reader!=null)reader.close();}catch(Exception ignored){}session=null;camera=null;reader=null;}
}
