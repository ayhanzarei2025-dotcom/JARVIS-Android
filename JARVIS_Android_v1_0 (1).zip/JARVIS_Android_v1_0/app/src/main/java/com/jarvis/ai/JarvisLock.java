package com.jarvis.ai;

import android.content.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class JarvisLock {
 private static final String PREF="jarvis_lock";
 private static final String HASH="password_hash";
 private JarvisLock(){}
 public static boolean isConfigured(Context c){return c.getSharedPreferences(PREF,0).contains(HASH);}
 public static void ensureDefault(Context c){if(!isConfigured(c)) setPassword(c,"ayhan2012");}
 public static void setPassword(Context c,String p){c.getSharedPreferences(PREF,0).edit().putString(HASH,sha256(p)).apply();}
 public static boolean verify(Context c,String p){String h=c.getSharedPreferences(PREF,0).getString(HASH,"");return !h.isEmpty()&&h.equals(sha256(p));}
 private static String sha256(String s){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(byte q:b)x.append(String.format("%02x",q));return x.toString();}catch(Exception e){return "";}}
}
