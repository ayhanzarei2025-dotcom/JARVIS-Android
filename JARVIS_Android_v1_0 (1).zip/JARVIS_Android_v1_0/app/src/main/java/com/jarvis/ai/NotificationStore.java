package com.jarvis.ai;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.text.*;
import java.util.*;

public class NotificationStore extends SQLiteOpenHelper {
 private static final String DB="jarvis_notifications.db";
 public NotificationStore(Context c){super(c,DB,null,1);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT, app TEXT, title TEXT, body TEXT, ts INTEGER, handled INTEGER DEFAULT 0)");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){d.execSQL("DROP TABLE IF EXISTS notifications");onCreate(d);}
 public synchronized void add(String pkg,String app,String title,String body){SQLiteDatabase d=getWritableDatabase();ContentValues v=new ContentValues();v.put("pkg",pkg);v.put("app",app);v.put("title",title);v.put("body",body);v.put("ts",System.currentTimeMillis());d.insert("notifications",null,v);}
 public synchronized String recent(int limit){StringBuilder s=new StringBuilder();Cursor c=getReadableDatabase().query("notifications",null,null,null,null,null,"ts DESC",String.valueOf(limit));try{while(c.moveToNext()){s.append(format(c)).append("\n");}}finally{c.close();}return s.toString();}
 public synchronized String unreadSince(long since,int limit){StringBuilder s=new StringBuilder();Cursor c=getReadableDatabase().query("notifications",null,"ts>=?",new String[]{String.valueOf(since)},null,null,"ts ASC",String.valueOf(limit));try{while(c.moveToNext())s.append(format(c)).append("\n");}finally{c.close();}return s.toString();}
 public synchronized int countSince(long since){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM notifications WHERE ts>=?",new String[]{String.valueOf(since)});try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
 private String format(Cursor c){long ts=c.getLong(c.getColumnIndexOrThrow("ts"));String t=c.getString(c.getColumnIndexOrThrow("title"));String b=c.getString(c.getColumnIndexOrThrow("body"));String a=c.getString(c.getColumnIndexOrThrow("app"));return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date(ts))+" | "+a+" | "+t+(b==null||b.isEmpty()?"":" | "+b);}
}
