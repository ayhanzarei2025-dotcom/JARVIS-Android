package com.jarvis.ai;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;

public class JarvisNotificationListener extends NotificationListenerService {
 private NotificationStore store;
 @Override public void onCreate(){super.onCreate();store=new NotificationStore(this);}
 @Override public void onNotificationPosted(StatusBarNotification sbn){
  Notification n=sbn.getNotification(); if(n==null||n.extras==null)return;
  Bundle e=n.extras; CharSequence title=e.getCharSequence(Notification.EXTRA_TITLE); CharSequence text=e.getCharSequence(Notification.EXTRA_TEXT);
  if(title==null&&text==null)return;
  String app=sbn.getPackageName(); try{app=(String)getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(app,0));}catch(Exception ignored){}
  store.add(sbn.getPackageName(),app,title==null?"":title.toString(),text==null?"":text.toString());
 }
}
