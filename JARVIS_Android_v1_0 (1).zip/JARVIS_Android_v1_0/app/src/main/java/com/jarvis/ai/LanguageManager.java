package com.jarvis.ai;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.*;

/** Multilingual voice helper: language detection + TTS selection. */
public final class LanguageManager {
    private final TextToSpeech tts;
    private float speechRate = 1.0f;
    private float pitch = 1.0f;
    public LanguageManager(TextToSpeech tts){this.tts=tts;}
    public void setSpeechRate(float r){speechRate=Math.max(.5f,Math.min(2.0f,r)); if(tts!=null)tts.setSpeechRate(speechRate);}
    public float getSpeechRate(){return speechRate;}
    public String detect(String s){
        if(s==null||s.trim().isEmpty())return "en-US";
        int fa=0,ar=0,lat=0;
        for(int i=0;i<s.length();i++){char c=s.charAt(i); if(c>='\u0600'&&c<='\u06FF'){if(c=='ی'||c=='ک'||c=='گ'||c=='پ'||c=='ژ'||c=='چ')fa++; else ar++;} else if((c>='A'&&c<='Z')||(c>='a'&&c<='z'))lat++;}
        if(fa>=2 && fa>=ar)return "fa-IR";
        if(ar>=2)return "ar-SA";
        return "en-US";
    }
    public boolean selectForText(String s){return select(detect(s));}
    public boolean select(String tag){
        if(tts==null)return false;
        Locale l=locale(tag); if(l==null)return false;
        int r=tts.setLanguage(l); return r!=TextToSpeech.LANG_MISSING_DATA && r!=TextToSpeech.LANG_NOT_SUPPORTED;
    }
    private Locale locale(String tag){
        if(tag.startsWith("fa"))return new Locale("fa","IR");
        if(tag.startsWith("ar"))return new Locale("ar","SA");
        if(tag.startsWith("tr"))return new Locale("tr","TR");
        if(tag.startsWith("de"))return Locale.GERMAN;
        if(tag.startsWith("fr"))return Locale.FRENCH;
        if(tag.startsWith("es"))return new Locale("es","ES");
        return Locale.US;
    }
}
