package com.jarvis.ai;

import android.content.Context;
import android.graphics.*;
import android.os.BatteryManager;
import android.util.AttributeSet;
import android.view.View;

/** Lightweight, dependency-free Iron-Man-inspired HUD overlay. */
public final class HudView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float pulse = 0f;
    private String mode = "STANDBY";
    private boolean vision = false;
    private int battery = -1;

    public HudView(Context c) { super(c); init(); }
    public HudView(Context c, AttributeSet a) { super(c, a); init(); }
    private void init() { p.setTypeface(Typeface.create("monospace", Typeface.NORMAL)); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    public void setMode(String m) { mode = m == null ? "STANDBY" : m.toUpperCase(); invalidate(); }
    public void setVision(boolean v) { vision = v; invalidate(); }
    public void setBattery(int b) { battery = b; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
        pulse += 0.045f; if(pulse>Math.PI*2) pulse=0;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(Color.argb(175,90,230,255));
        float r=Math.min(w,h)*0.19f;
        c.drawCircle(cx,cy,r,p); c.drawCircle(cx,cy,r*1.35f,p);
        c.drawArc(cx-r*1.65f,cy-r*1.65f,cx+r*1.65f,cy+r*1.65f,-35,105,false,p);
        c.drawArc(cx-r*1.65f,cy-r*1.65f,cx+r*1.65f,cy+r*1.65f,145,82,false,p);
        p.setStrokeWidth(1f); p.setColor(Color.argb(90,90,230,255));
        c.drawLine(cx-r*1.8f,cy,cx+r*1.8f,cy,p); c.drawLine(cx,cy-r*1.8f,cx,cy+r*1.8f,p);
        // corner brackets
        float m=18, s=58; Path q=new Path();
        q.moveTo(m,m+s);q.lineTo(m,m);q.lineTo(m+s,m);c.drawPath(q,p);
        q.reset();q.moveTo(w-m-s,m);q.lineTo(w-m,m);q.lineTo(w-m,m+s);c.drawPath(q,p);
        q.reset();q.moveTo(m,h-m-s);q.lineTo(m,h-m);q.lineTo(m+s,h-m);c.drawPath(q,p);
        q.reset();q.moveTo(w-m-s,h-m);q.lineTo(w-m,h-m);q.lineTo(w-m,h-m-s);c.drawPath(q,p);
        p.setStyle(Paint.Style.FILL);p.setTextSize(12);p.setColor(Color.argb(210,170,245,255));
        c.drawText("J.A.R.V.I.S // V6",m+8,m+18,p); c.drawText("MODE  "+mode,w-m-145,m+18,p);
        c.drawText(vision?"OPTICS  ONLINE":"OPTICS  STANDBY",m+8,h-m-28,p);
        c.drawText("BAT  "+(battery<0?"--":battery+"%"),w-m-85,h-m-28,p);
        c.drawText("◉",cx-4,cy+4,p);
        p.setTextSize(10); c.drawText("TARGET / ANALYSIS",cx-48,cy+r*1.75f,p);
        if(vision){
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2f);p.setColor(Color.argb(220,120,255,190));
            float rr=r*(1.08f+0.03f*(float)Math.sin(pulse));c.drawCircle(cx,cy,rr,p);
            postInvalidateDelayed(33);
        }
    }
}
