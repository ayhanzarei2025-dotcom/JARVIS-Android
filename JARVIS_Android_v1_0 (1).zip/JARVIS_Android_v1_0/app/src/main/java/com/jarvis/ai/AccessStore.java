package com.jarvis.ai;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.text.*;
import java.util.*;

public class AccessStore extends SQLiteOpenHelper {
 private static final String DB="jarvis_access.db";
 public AccessStore(Context c){super(c,DB,null,1);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE screen_events(id INTEGER PRIMARY KEY AUTOINCREMENT,pkg TEXT,app TEXT,text TEXT,ts INTEGER)"); d.execSQL("CREATE TABLE allowed_apps(pkg TEXT PRIMARY KEY,app TEXT)");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){d.execSQL("DROP TABLE IF EXISTS screen_events");d.execSQL("DROP TABLE IF EXISTS allowed_apps");onCreate(d);}
 public synchronized void addScreenText(String pkg,String app,String text){if(text==null||text.trim().isEmpty()||!isAllowed(pkg))return; SQLiteDatabase d=getWritableDatabase();ContentValues v=new ContentValues();v.put("pkg",pkg);v.put("app",app);v.put("text",text.trim());v.put("ts",System.currentTimeMillis());d.insert("screen_events",null,v);}
 public synchronized boolean isAllowed(String pkg){Cursor c=getReadableDatabase().query("allowed_apps",new String[]{"pkg"},"pkg=?",new String[]{pkg},null,null,null,"1");try{return c.moveToFirst();}finally{c.close();}}
 public synchronized void setAllowed(String pkg,String app,boolean yes){SQLiteDatabase d=getWritableDatabase();if(yes){ContentValues v=new ContentValues();v.put("pkg",pkg);v.put("app",app);d.insertWithOnConflict("allowed_apps",null,v,SQLiteDatabase.CONFLICT_REPLACE);}else d.delete("allowed_apps","pkg=?",new String[]{pkg});}
 public synchronized String allowed(){StringBuilder s=new StringBuilder();Cursor c=getReadableDatabase().query("allowed_apps",null,null,null,null,null,"app ASC");try{while(c.moveToNext())s.append(c.getString(c.getColumnIndexOrThrow("pkg"))).append(" | ").append(c.getString(c.getColumnIndexOrThrow("app"))).append("\n");}finally{c.close();}return s.toString();}
 public synchronized String recentScreen(int limit){StringBuilder s=new StringBuilder();Cursor c=getReadableDatabase().query("screen_events",null,null,null,null,null,"ts DESC",String.valueOf(limit));try{while(c.moveToNext()){long ts=c.getLong(c.getColumnIndexOrThrow("ts"));String app=c.getString(c.getColumnIndexOrThrow("app"));String txt=c.getString(c.getColumnIndexOrThrow("text"));s.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(ts))).append(" | ").append(app).append(" | ").append(txt).append("\n");}}finally{c.close();}return s.toString();}
}
