package com.jarvis.ai;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.*;
import android.content.pm.PackageManager;
import java.util.*;

public class JarvisAccessibilityService extends AccessibilityService {
 private AccessStore store;
 @Override public void onServiceConnected(){super.onServiceConnected();store=new AccessStore(this);}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){if(store==null||e==null)return;CharSequence pn=e.getPackageName();if(pn==null||getPackageName().contentEquals(pn))return;String pkg=pn.toString();if(!store.isAllowed(pkg))return;AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;StringBuilder b=new StringBuilder();collect(root,b,new HashSet<AccessibilityNodeInfo>());String text=b.toString().trim();if(text.length()>0){String app=pkg;try{app=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)).toString();}catch(Exception ignored){}if(text.length()>12000)text=text.substring(0,12000);store.addScreenText(pkg,app,text);}}
 private void collect(AccessibilityNodeInfo n,StringBuilder b,Set<AccessibilityNodeInfo> seen){if(n==null||seen.contains(n))return;seen.add(n);CharSequence t=n.getText();if(t!=null&&t.length()>0){if(b.length()>0)b.append(" ");b.append(t);}for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),b,seen);}
 @Override public void onInterrupt(){}
}
