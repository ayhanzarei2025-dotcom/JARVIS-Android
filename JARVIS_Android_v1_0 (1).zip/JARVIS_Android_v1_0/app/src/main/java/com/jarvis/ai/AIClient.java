package com.jarvis.ai;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Small dependency-free HTTP client for OpenAI-compatible chat/vision endpoints. */
public final class AIClient {
 public interface Callback{void started();void token(String t);void done(String t);void error(String m);}
 public static final class Message{final String role,content; public Message(String r,String c){role=r;content=c;}}
 private final String endpoint,key,model; private volatile boolean cancelled;
 public AIClient(String endpoint,String key,String model){this.endpoint=endpoint.replaceAll("/$","");this.key=key;this.model=model;}
 public void cancel(){cancelled=true;}
 public void ask(String system,List<Message> history,String user,boolean stream,Callback cb){
  JSONArray msgs=new JSONArray(); msgs.put(new JSONObject().put("role","system").put("content",system));
  for(Message m:history)msgs.put(new JSONObject().put("role",m.role).put("content",m.content));
  msgs.put(new JSONObject().put("role","user").put("content",user));
  request(new JSONObject().put("model",model).put("messages",msgs).put("temperature",0.35).put("stream",stream),stream,cb);
 }
 /** Vision request: sends a JPEG as a data URL in the standard multimodal message shape. */
 public void askVision(String system,List<Message> history,String prompt,String jpegBase64,boolean stream,Callback cb){
  JSONArray msgs=new JSONArray(); msgs.put(new JSONObject().put("role","system").put("content",system));
  for(Message m:history)msgs.put(new JSONObject().put("role",m.role).put("content",m.content));
  JSONArray content=new JSONArray();
  content.put(new JSONObject().put("type","text").put("text",prompt));
  content.put(new JSONObject().put("type","image_url").put("image_url",new JSONObject().put("url","data:image/jpeg;base64,"+jpegBase64)));
  msgs.put(new JSONObject().put("role","user").put("content",content));
  request(new JSONObject().put("model",model).put("messages",msgs).put("temperature",0.2).put("stream",stream),stream,cb);
 }
 private void request(JSONObject body,boolean stream,Callback cb){new Thread(()->{HttpURLConnection c=null;try{
   URL u=new URL(endpoint.endsWith("/chat/completions")?endpoint:endpoint+"/chat/completions"); c=(HttpURLConnection)u.openConnection();
   c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(120000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");
   c.setRequestProperty("Accept",stream?"text/event-stream":"application/json");if(!key.isEmpty())c.setRequestProperty("Authorization","Bearer "+key);
   try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
   int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
   if(code<200||code>=300)throw new IOException("HTTP "+code+": "+read(in,1600)); cb.started();
   if(stream)cb.done(readSSE(in,cb).trim()); else {String r=read(in,0);String a=new JSONObject(r).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content","").trim();if(!a.isEmpty())cb.token(a);cb.done(a);}
  }catch(Exception e){if(!cancelled)cb.error(e.getMessage()==null?"AI request failed":e.getMessage());}finally{if(c!=null)c.disconnect();}}).start();}
 private String readSSE(InputStream in,Callback cb)throws Exception{BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder all=new StringBuilder();String line;
  while(!cancelled&&(line=br.readLine())!=null){if(!line.startsWith("data:"))continue;String d=line.substring(5).trim();if(d.equals("[DONE]"))break;try{JSONObject o=new JSONObject(d);JSONArray ch=o.optJSONArray("choices");if(ch==null||ch.length()==0)continue;JSONObject delta=ch.getJSONObject(0).optJSONObject("delta");if(delta==null)continue;String t=delta.optString("content","");if(!t.isEmpty()){all.append(t);cb.token(t);}}catch(JSONException ignored){}}
  return all.toString();}
 private static String read(InputStream in,int cap)throws Exception{if(in==null)return "";BufferedReader b=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String x;while((x=b.readLine())!=null){s.append(x);if(cap>0&&s.length()>cap)break;}return s.toString();}
}
