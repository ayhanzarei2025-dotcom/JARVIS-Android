package com.jarvis.ai;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/** Opens the user's installed browser with a search query. No hidden browsing or credential access. */
public final class WebSearch {
    private WebSearch(){}
    public static boolean open(Context c,String query){
        String q=query==null?"":query.trim(); if(q.isEmpty())return false;
        try { Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q="+Uri.encode(q))); c.startActivity(i); return true; }
        catch(Exception e){return false;}
    }
}
